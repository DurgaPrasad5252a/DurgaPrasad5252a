export class Details {
  id: any;
  FullName: string;
  ObtainedMarks: number;

  constructor(id: any, FullName: string, ObtainedMarks: number) {
    this.id = id;
    this.FullName = FullName;
    this.ObtainedMarks = ObtainedMarks;
  }
}
