import { Students } from './students';

describe('Students', () => {
  it('should create an instance', () => {
    expect(new Students()).toBeTruthy();
  });
});
